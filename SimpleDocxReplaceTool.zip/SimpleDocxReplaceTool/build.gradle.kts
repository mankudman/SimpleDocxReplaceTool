plugins {
    `java-library`
}

repositories {
    jcenter()
}

dependencies {
    implementation("org.apache.poi:poi:4.1.1")
    implementation("org.apache.poi:poi-ooxml:4.1.1")
    implementation("org.apache.poi:poi-scratchpad:4.1.1")
    implementation("org.apache.poi:ooxml-schemas:1.4")

    testImplementation("org.junit.jupiter:junit-jupiter-api:5.4.2")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.4.2")
}

val test by tasks.getting(Test::class) {
    useJUnitPlatform()
}
