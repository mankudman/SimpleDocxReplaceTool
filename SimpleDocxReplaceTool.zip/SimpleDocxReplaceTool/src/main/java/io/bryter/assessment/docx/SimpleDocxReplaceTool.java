package io.bryter.assessment.docx;

import java.io.*;
import java.util.List;
import org.apache.poi.xwpf.usermodel.*;

public class SimpleDocxReplaceTool {

    protected FileInputStream m_docstream; //internal inputstream for document
    protected XWPFDocument m_docx; //internal XWPF representation of document
    protected String m_filename; //reference to string with specified file

    /**
     * Tests if a Docx is loaded in the tool
     *
     * @return will return 0 in case a Docx was loaded
     * successfully before with openDocx!
     */
    public int isDocxLoaded() {
        if (m_docx != null) {
            return 0; //ok!!! docx is loaded!
        }
        return -1; //no docx loaded!
    }

    /**
     * Closes the Docx releasing resources and allows for
     * subsequent opening of other Docx documents with the
     * openDocx method!
     *
     * @return -1 is returned in case of error, 0 otherwise
     */
    public int closeDocx() {
        if (m_docstream != null) {
            try {
                m_docstream.close();
                m_docx.close();
            }
            catch (Exception e) {
                return -1; //something bad happened when closing!
            }
            finally {
                //set references to null to reset ReplaceTool
                //and hoping the garbage will be collected
                m_docstream = null;
                m_docx = null;
            }
            return 0; //closing ok!!!
        }
        return 0; //nothing to close, so it's ok!!!
    }

    /**
     * The method openDocx opens the specified .docx file and
     * loads it in an internal XWPFDocument representation.
     *
     * @param filename specification of filename and path
     * @return -1 is returned in case of error, 0 otherwise
     */
    public int openDocx(String filename) {
        if (m_docx != null) {
            return -1; //already loaded, please close first!
        }

        try {
            m_docstream = new FileInputStream(filename);
            m_docx = new XWPFDocument(m_docstream);
        } catch (Exception e) {
            //catching a generic exception here, just simple error handling!
            m_docstream = null; //clean w/o closing
            m_docx = null; //clean w/o closing
            return -1; //sorry, file not found or exception in XWPF!
        }

        m_filename = filename;
        return 0; //open was ok!!!
    }

    /**
     * This method writes the current state of the internal
     * document representation to the specified file.
     *
     * @param filename specification of filename and path
     * @return -1 is returned in case of error, 0 otherwise
     */
    public int writeDocx(String filename) {
        if (m_docx == null) return -1; //no docx loaded!!!

        //open file for writing
        FileOutputStream outstream;
        try {
            outstream = new FileOutputStream(filename);
        }
        catch (Exception e)
        {
            return -1; //file could not be created or opened for writing
        }

        //write the manipulated docx to the new file and close
        try {
            m_docx.write(outstream);
            outstream.flush();
            outstream.close();
        }
        catch (Exception e) {
            return -1; //IO exception problem!!!
        }

        return 0; //success writing to file!!!
    }

    /**
     * This method outputs some Document details to a specified PrintStream.
     *
     * @param output specifies the PrintStream for outputting the file details
     * @return -1 is returned in case of error, 0 otherwise
     */
    public int analyseDocx(PrintStream output) {
        if (m_docx == null) {
            return -1;
        }
        output.println("\n************ ANALYSE DOCX ************");
        output.println("* Filename: "+ m_filename);

        int numofparas = m_docx.getParagraphs().size();
        output.println("* Number of Paragraphs: " + numofparas);

        List<IBodyElement> bodies = m_docx.getBodyElements();
        output.println("* Main-Bodies of Document:");
        int bodynumber = 1;
        for (IBodyElement body : bodies)
        {
            String bodytype = "";
            switch (body.getPartType())
            {
                case CONTENTCONTROL: bodytype = "CONTENTCONTROL"; break;
                case DOCUMENT: bodytype = "DOCUMENT"; break;
                case HEADER: bodytype = "HEADER"; break;
                case FOOTER: bodytype = "FOOTER"; break;
                case FOOTNOTE: bodytype = "FOOTNOTE"; break;
                case TABLECELL: bodytype = "TABLECELL"; break;
                default: bodytype = "UNKNOWN"; break;
            }
            output.println("*   " + bodynumber + ") PartType = " + bodytype);
            bodynumber++;
        }
        output.println("**************************************\n");
        return 0;
    }

    /**
     * This is just a simple finder, to test if a string occurs inside
     * the loaded document. If the string is found inside the document,
     * an integer greater than 0 is returned (representing the number
     * of text runs in the XWPFDocument where the string occurs)
     *
     * @param findtext specifies the string to be found
     * @return -1 is returned in case of error, 0 if nothing is found,
     * 1 or higher if the string is found
     */
    public int textFind(String findtext) {
        if (m_docx == null) {
            return -1; //no docx loaded!!!
        }

        if (findtext == null) {
            return -1; //bad arg
        }

        //search for occurrences in text runs
        int num_of_matching_runs = 0;
        List<XWPFParagraph> paras = m_docx.getParagraphs();
        if (paras == null) return 0; //nothing found
        for (XWPFParagraph p : paras) {
            List<XWPFRun> runs = p.getRuns();
            if (runs == null) continue;
            for (XWPFRun r : runs) {
                String runtext = r.getText(0);
                if (runtext == null) continue;
                if (runtext.contains(findtext)) num_of_matching_runs++;
            }
        }

        return num_of_matching_runs; //success!!! amount of runs where text was found in
    }

    /**
     * Will replace all occurrences of 'findtext' with 'replacetext'
     * inside the internally loaded XWPFDocument
     *
     * @param findtext specifies the string to be found
     * @param replacetext specifies the replacing string
     * @return -1 is returned in case of error, 0 if nothing is replaced,
     * 1 or higher if the string is found and replaced (num. of text runs)
     */
    public int textReplaceAll(String findtext, String replacetext) {
        if (m_docx == null) {
            return -1; //no docx loaded!!!
        }

        if (findtext == null || replacetext== null) {
            return -1; //bad args
        }

        //search and replace the occurrence!
        //** Text spanning across several paragraphs should not be considered, just
        //** search and replace within paragraphs. Text spanning across several text
        //** runs should not be considered. Tables, objects, header and footers are
        //** out of scope, too. Formatting does not need to be considered neither.
        int num_of_matching_runs = 0;
        List<XWPFParagraph> paras = m_docx.getParagraphs();
        if (paras == null) return 0; //nothing replaced
        for (XWPFParagraph p : paras) {
            List<XWPFRun> runs = p.getRuns();
            if (runs == null) continue;
            for (XWPFRun r : runs) {
                String runtext = r.getText(0);
                if (runtext == null) continue;
                if (runtext.contains(findtext)) {
                    num_of_matching_runs++; //this run has the string at least once!
                    runtext = runtext.replace(findtext, replacetext); //replace all matches!
                    r.setText(runtext, 0); //and sets the text of this run
                }
            }
        }

        return num_of_matching_runs; //success!!! amount of runs where text was replaced in
    }
}
